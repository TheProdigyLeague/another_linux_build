ZEDFREE 2023.2 

On system Ubuntu 22.04, use installer in "Ubuntu 22.04" folder.
On system Ubuntu 20.04 or 18.04, use installer in "Ubuntu 20.04" folder.

Copyright Prim'X Technologies.